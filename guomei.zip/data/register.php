<?php
header("Content-Type:html/plian");
?>