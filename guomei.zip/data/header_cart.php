<?php
header("Content-Type:html/plian");
?>
 <header id="header">
        <div class="lf">
            <b>
                <a href="#">国美会员</a>
                <span></span>
                <div class="vip">
                    <div class="denglu">
                        <i></i>
                        <span>欢迎来到国美在线，
                             <a href="#">请登录！</a>
                        </span>
                    </div>
                    <p>
                        <a class="lf" href="#">我的特权</a>
                        <a class="rt" href="#">会员俱乐部</a>
                    </p>
                    <div class="vip_privilege">
                        <i></i>
                        <dl>
                            <dd><a href="#"><img src="image/11.png" alt=""/></a></dd>
                            <dt><a href="#">没豆抽奖</a></dt>
                        </dl>
                        <dl>
                            <dd><a href="#"><img src="image/22.png" alt=""/></a></dd>
                            <dt><a href="#">退换货保障</a></dt>
                        </dl>
                        <dl>
                            <dd><a href="#"><img src="image/33.png" alt=""/></a></dd>
                            <dt><a href="#">价格保护</a></dt>
                        </dl>
                        <i></i>

                    </div>

                </div>

            </b>
			<span id="user">
				
			</span>
            
        </div>
        <div class="rt">
            <a href="#">我的订单</a>
            <span class="my_gm">
                <a href="#">我的国美</a>
                <span></span>
                <div class="my_gm_list">
                    <div>
                        <ul>
                            <b>我的国美，</b><a href="#" id="denglu">请登录</a>
                            <li><a href="#">待处理订单</a></li>
                            <li><a href="#">我的收藏</a></li>
                            <li><a href="#">我的金融</a></li>
                            <li><a href="#">个人资料</a></li>
                        </ul>
                    </div>
                    <div>
                        <ul>
                            <li><a href="#">红券</a></li>
                            <li><a href="#">蓝券</a></li>
                            <li><a href="#">店铺卷</a></li>
                            <li><a href="#">购物券</a></li>
                            <li>-</li>
                            <li>-</li>
                            <li>-</li>
                            <li>-</li>
                        </ul>
                    </div>
                    <div>
                        <p>足迹</p>
                        <i></i>
                        <i></i>
                        <i></i>
                        <i></i>
                    </div>
                </div>
            </span>
            <a href="#">企业采购</a>
            <span class="service">
                <i></i>
                <a href="#">服务中心</a>
                <div class="service_list">
                     <h4>售后服务</h4>
                        <a href="#">物流配送</a>
                        <a href="#">上门安装</a>
                        <a href="#">退换货服务</a>
                        <a href="#">手机维修</a>
                        <a href="#">延保服务</a>
                        <a href="#">家电回收</a>
                        <h4>帮助服务</h4>
                        <a href="#">焦点问点</a>
                        <a href="#">账户安全</a>
                        <a href="#">签收与验收</a>
                        <a href="#">分期付款</a>
                        <a href="#">退货说明</a>
                        <a href="#">优惠券说明</a>
                    <a href="#">
                        <i></i>
                        在线客服
                    </a>

                </div>
            </span>
            <span class="web_nav">
                <a href="#">网站导航</a>
                <span></span>
                <div class="web_nav_list">
                    <dl>
                      <dd><h3>主题促销</h3></dd>
                      <dt>
                          <ul>
                              <li><a href="#">真划算</a></li>
                              <li><a href="#">抢购</a></li>
                              <li><a href="#">海外购</a></li>
                              <li><a href="#">闪购</a></li>
                          </ul>
                        <ul>
                            <li><a href="#">家电城</a></li>
                            <li><a href="#">服饰城</a></li>
                            <li><a href="#">国美超市</a></li>
                            <li><a href="#">家装馆</a></li>
                        </ul>
                        <ul>
                            <li><a href="#">智能家居</a></li>
                            <li><a href="#">今日特卖</a></li>
                            <li><a href="#">新品抢先</a></li>
                            <li><a href="#">品牌街</a></li>
                        </ul>

                      </dt>
                  </dl>
                    <dl>
                        <dd><h3>特色分类</h3></dd>
                        <dt>
                        <ul>
                            <li><a href="#">电视影音</a></li>
                            <li><a href="#">冰洗</a></li>
                            <li><a href="#">洗衣机</a></li>
                            <li><a href="#">空调</a></li>
                            <li><a href="#">厨卫生活</a></li>
                        </ul>
                        <ul>
                            <li><a href="#">手机</a></li>
                            <li><a href="#">数码</a></li>
                            <li><a href="#">电脑办公</a></li>
                            <li><a href="#">精品配件</a></li>
                            <li><a href="#">汽车</a></li>
                        </ul>
                        <ul>
                            <li><a href="#">住宅家居</a></li>
                            <li><a href="#">家居家装</a></li>
                            <li><a href="#">家居日用</a></li>
                            <li><a href="#">床品家纺</a></li>
                            <li><a href="#">黄金收藏</a></li>
                        </ul>
                        <ul>
                            <li><a href="#">服装鞋帽</a></li>
                            <li><a href="#">运动户外</a></li>
                            <li><a href="#">箱包奢品</a></li>
                            <li><a href="#">钟表首饰</a></li>
                            <li><a href="#">文化艺术</a></li>
                        </ul>
                        <ul>
                            <li><a href="#">食品酒水</a></li>
                            <li><a href="#">医疗保健</a></li>
                            <li><a href="#">母婴玩具</a></li>
                            <li><a href="#">美妆个户</a></li>
                        </ul>
                        </dt>
                    </dl>
                    <dl>
                        <dd>
                            <h3>便捷服务</h3>
                        </dd>
                        <dt>
                            <ul>
                                <li><a href="#">话费充值</a></li>
                                <li><a href="#">游戏点卡</a></li>
                                <li><a href="#">机票</a></li>
                                <li><a href="#">电影票</a></li>
                                <li><a href="#">美盈宝</a></li>
                                <li><a href="#">定期理财</a></li>
                                <li><a href="#">白拿</a></li>
                                <li><a href="#">转让理财</a></li>
                            </ul>
                        <ul>
                            <li><a href="#">流量充值</a></li>
                            <li><a href="#">一元夺宝</a></li>
                            <li><a href="#">酒店</a></li>
                            <li><a href="#">火车票</a></li>
                            <li><a href="#">演出票</a></li>
                            <li><a href="#">头金宝</a></li>
                            <li><a href="#">票据理财</a></li>
                        </ul>
                        </dt>
                    </dl>
                    <dl>
                        <dd><h3>更多热点</h3></dd>
                        <dt>
                        <ul>
                            <li><a href="#">商家入驻</a></li>
                            <li><a href="#">企业采购</a></li>
                            <li><a href="#">国美社区</a></li>
                            <li><a href="#">购明白</a></li>
                        </ul>
                        </dt>
                    </dl>
                    <dl>
                        <dd><h3>国美旗下</h3></dd>
                        <dt>
                        <ul>
                            <li><a href="#">多边金都</a></li>
                            <li><a href="#">国之美</a></li>
                            <li><a href="#">国美家装</a></li>
                            <li><a href="#">更多板块</a></li>
                        </ul>
                        </dt>
                    </dl>
                </div>
            </span>
            <span class="phone_gm">
                <i></i>
                <a href="#">手机国美</a>
                <span></span>
                <div class="phone_gm_list">
                    <i></i>
                </div>

            </span>
        </div>
    </header>
   