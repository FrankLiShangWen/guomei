<?php
header("Content-Type:html/plian");
?>
<footer id="footer">
        <div class="shoihou">
            <ul>
                <li><a href="#">七天退换</a></li>
                <li><a href="#">专业维修</a></li>
                <li><a href="#">延保服务</a></li>
                <li><a href="#">回收服务</a></li>
                <li><a href="#">服务中心</a></li>
            </ul>
        </div>
        <div class="shoihou_boutom">
           <dl>
               <dd>
                   <a href="#">配送与物流</a>
               </dd>
               <dt>
                   <ul>
                       <li><a href="#">配送查询</a></li>
                       <li><a href="#">配送服务</a></li>
                       <li><a href="#">配送费用</a></li>
                       <li><a href="#">配送时效</a></li>
                       <li><a href="#"> 签收与验货</a></li>
                   </ul>
               </dt>
           </dl>
            <dl>
                <dd>
                    <a href="#">支付与账户</a>
                </dd>
                <dt>
                <ul>
                    <li><a href="#">货到付款</a></li>
                    <li><a href="#">在线支付</a></li>
                    <li><a href="#">分期付款</a></li>
                    <li><a href="#"> 门店支付</a></li>
                   <li><a href="#"> 账户安全</a></li>
                </ul>
                </dt>
            </dl>
            <dl>
                <dd>
                    <a href="#">售后服务</a>
                </dd>
                <dt>
                <ul>
                    <li><a href="#">退换货服务</a></li>
                    <li><a href="#">退款说明</a></li>
                    <li><a href="#">专业维修</a></li>
                    <li><a href="#"> 延保服务</a></li>
                    <li><a href="#"> 家电回收 </a></li>
                </ul>
                </dt>
            </dl>
            <dl>
                <dd>
                    <a href="#">会员专区</a>
                </dd>
                <dt>
                <ul>
                    <li><a href="#"> 会员介绍</a></li>
                    <li><a href="#">优惠券说明</a></li>
                    <li><a href="#">美豆说明</a></li>
                    <li><a href="#">国美社区</a></li>
                    <li><a href="#">商品评价</a></li>
                </ul>
                </dt>
            </dl>
            <dl>
                <dd>
                    <a href="#">购物帮助</a>
                </dd>
                <dt>
                <ul>
                    <li><a href="#">购物保障</a></li>
                    <li><a href="#"> 购物流程</a></li>
                    <li><a href="#">促销优惠</a></li>
                    <li><a href="#">焦点问题</a></li>
                    <li><a href="#"> 联系我们</a></li>
                </ul>
                </dt>
            </dl>
        </div>

    </footer>